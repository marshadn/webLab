<?php
include 'conn.php';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "select * from signup where email='$email' and password='$password'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);

    if ($num > 0) {
        header("location:12_user.php");
    } else {
        echo '<script>alert("Email and Password is not matching")</script>';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(124, 13, 87);
        }

        .container {
            max-width: 400px;
            margin-top: 170px;
            margin-left: 520px;
            padding: 20px;
            background-color: cyan;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 7px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            padding: 5px 5px;
            border: solid;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        #sign {
            font-size: 15px;
            border: #0056b3;
            color: white;
            background-color: #007BFF;
            border-radius: 8px;
            padding: 7px;
            margin-left: 15px;
        }

        a {
            text-decoration: none;
            margin-left: 5px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>LOGIN</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="email">Username</label>
                <input type="text" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="submit" id="sign">Login</button>
            Don't Have An Account?<a href="11_signup.php">Signup Here</a>

        </form>
    </div>
</body>

</html>

<!-- if (isset($_POST['submit'])) {
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "insert into mars(username,password)values('$username','$password')";
$result = mysqli_query($conn, $sql);

if ($result) {
echo '<script>
    alert("Inserted Suceesfully")
</script>';
} else {
echo '<script>
    alert("Insertion Falied")
</script>';
}
} -->