<?php
include '12_con.php';

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    $sql = "INSERT INTO crud(name,email,mobile,password)VALUES('$name','$email','$mobile','$password')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        //echo "<script>alert('Data inserted sucessfully')</script>";
        header('location:12_display.php');
    } else {
        echo "<script>alert('Failed')</script>";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocumenUser Info</title>
    <style>
        .content {
            margin-top: 120px;
            font-size: 20px;
        }

        input {
            font-size: 18px;
            height: 20px;
            align-items: center;
            justify-content: center;
        }

        #sub {
            color: blanchedalmond;
            background-color: blue;

            border: black;
            border-radius: 3px;
            font-size: 12px;
            display: inline-block;
            text-align: center;
            cursor: pointer;



        }
    </style>
</head>

<body>
    <div class="content">
        <center>
            <form action="" method="post">
                <h2>User Info</h2>
                <label for="">Name:</label>
                <input type="text" placeholder="Enter username here" name="name"><br><br>
                <label for="">Email:</label>
                <input type="text" placeholder="Enter email here" name="email"><br><br>
                <label for="">Mobile:</label>
                <input type="text" placeholder="Enter mobil no here" name="mobile"><br><br>
                <label for="">Password:</label>
                <input type="password" placeholder="Enter password here" name="password"><br><br>
                <input type="submit" value="submit" id="sub" name="submit">
            </form>
        </center>
    </div>
</body>

</html>