<!-- 

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factorial</title>
    <style>
        .con {
            margin-top: 200px;
        }
    </style>
</head>

<body>
    <div class="con">
        <center>
            <form method="post" action="">
                <table>
                    <tr>
                        <td><label for="facto">Enter Number:</label></td>
                        <td><input type="number" name="facto" value="></td>
                        <td><button type="submit" name="submit">Submit</button></td>
                    </tr><br><br><br><br>
                    <tr>
                        <td><label for="result">Result:</label></td>
                        <td><input type="number" name="result" value= readonly></td>
                        <td><button type="reset" name="reset">Reset</button></td>
                    </tr>
                </table>
            </form>
        </center>
    </div>
</body>

</html>  -->



<?php
$fact = 1;
$n = 0;

if (isset($_POST['submit'])) {
    $n = $_POST['facto'];
    for ($i = 1; $i <= $n; $i++) {
        $fact *= $i;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factorial</title>
    <style>
        .con {
            margin-top: 200px;
        }
    </style>
</head>

<body>
    <div class="con">
        <center>
            <form method="post" action="07_factOG.php" id="myForm">
                <table>
                    <tr>
                        <td><label for="facto">Enter Number:</label></td>
                        <td><input type="number" name="facto" value="<?php echo $n; ?>"></td>
                        <td><button type="submit" name="submit">Submit</button></td>
                    </tr><br><br><br><br>
                    <tr>
                        <td><label for="result">Result:</label></td>
                        <td><input type="number" name="result" value="<?php echo $fact; ?>" readonly></td>
                        <td><input type="button" onclick="myFunc()" value="Reset"></td>
                    </tr>
                </table>
            </form>
        </center>
    </div>
    <script>
        function myFunc() {
            document.getElementById("myForm").reset();
        }
    </script>
</body>

</html>