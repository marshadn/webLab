<?php
include '12_con.php';

if (isset($_POST['search'])) {
    $searchName = $_POST['searchName'];
    $sql = "SELECT * FROM crud WHERE name LIKE '%$searchName%'";
} else {
    $sql = "SELECT * FROM crud";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <style>
        #btn {
            margin-bottom: 10px;
            text-decoration: none;
            background-color: blue;
        }

        a {
            text-decoration: none;
            color: white;
        }

        #update {
            color: green;
        }
    </style>
</head>

<body>
    <center>
        <form action="" method="post">
            <h2>User Details</h2>
            <label for="searchName">Search by Name: </label>
            <input type="text" name="searchName" id="searchName">
            <input type="submit" name="search" value="Search">
            <button style="padding: 5px; " , id="btn" name="sub"><a href="12_user.php">Add User</a></button>
            <table border="1px" width="70%">
                <tr>
                    <td align="center">id</td>
                    <td align="center">Name</td>
                    <td align="center">Email</td>
                    <td align="center">Mobile</td>
                    <td align="center">Password</td>
                    <td align="center">Operations</td>
                </tr>
                <?php
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $name = $row['name'];
                        $email = $row['email'];
                        $mobile = $row['mobile'];
                        $password = $row['password'];
                        echo '<tr><td>' . $id . '</td>
                        <td align="center">' . $name . '</td>
                        <td align="center">' . $email . '</td>
                        <td align="center">' . $mobile . '</td>
                        <td align="center">' . $password . '</td>
                        <td align="center"><button id="update" name="update" style="background-color: green;"><a href="12_update.php?updateid=' . $id . '">Update</a></button>
                        <button id="delete" name="delete" style="background-color: red;"><a href="12_delete.php?deleteid=' . $id . '">Delete</a></button></td>
                        </tr>';
                    }
                }
                ?>
            </table>
        </form>
    </center>
</body>

</html>