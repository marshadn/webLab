<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "info";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {

    echo "failed";
}
