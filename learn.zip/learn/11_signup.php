<?php
include 'conn.php';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "select * from signup where email='$email'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);

    if ($num > 0) {
        echo '<script>alert("Email already exists")</script>';
    } else {
        $insert = "INSERT INTO signup(email,password)VALUES('$email','$password')";
        mysqli_query($conn, $insert);
        header("location:11_login.php");
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(124, 13, 87);
        }

        .container {
            max-width: 400px;
            margin-top: 170px;
            margin-left: 520px;
            padding: 20px;
            background-color: cyan;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        #sign {
            font-size: 15px;
            border: #0056b3;
            color: white;
            background-color: #007BFF;
            border-radius: 8px;
            padding: 7px;
        }

        a {
            text-decoration: none;
            margin-left: 5px;
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 7px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            padding: 5px 5px;
            border: solid;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>SIGNUP</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="submit" id="sign">SIGNUP</button>
            Already Have An Account?<a href="11_login.php">Login Here</a>

        </form>
    </div>
</body>

</html>