<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information Form</title>
    <style>
        table {
            width: 60%;
            margin-top: 20px;
            margin-left: 250px;

        }

        table,
        th,
        td {
            border: 2px solid black;
        }

        th,
        td {
            /* padding: 10px; */
            text-align: left;
        }

        h1 {
            text-align: center;
        }

        #btn {
            justify-content: center;
            align-items: center;
            margin-left: 350px;
        }
    </style>
</head>

<body>
    <?php

    // Collecting form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $languagesKnown = $_POST['languagesKnown'];
    $homeNo = $_POST['homeNo'];
    $officeNo = $_POST['officeNo'];

    echo "Welcome " . $firstName;

    // Displaying submitted information
    // echo '<table border="2px">';
    // echo "<h2>Submitted Information:</h2>";
    // echo "<p><strong>First Name:</strong> $firstName</p>";
    // echo "<p><strong>Last Name:</strong> $lastName</p>";
    // echo "<p><strong>Age:</strong> $age</p>";
    // echo "<p><strong>Email:</strong> $email</p>";
    // echo "<p><strong>Languages Known:</strong> " . implode(', ', $languagesKnown) . "</p>";
    // echo "<p><strong>Home No:</strong> $homeNo</p>";
    // echo "<p><strong>Office No:</strong> $officeNo</p>";
    // echo "</table>";

    ?>
    <h1>User Information Form</h1>
    <form action="06_form.php" method="POST">
        <table>
            <tr>
                <td><label for="firstName">First Name:</label></td>
                <td><input type="text" name="firstName" required></td>
            </tr>
            <tr>
                <td><label for="lastName">Last Name:</label></td>
                <td><input type="text" name="lastName" required></td>
            </tr>
            <tr>
                <td><label for="age">Age:</label></td>
                <td><input type="number" name="age" required></td>
            </tr>
            <tr>
                <td><label for="email">Email:</label></td>
                <td><input type="email" name="email" required></td>
            </tr>
            <tr>
                <td><label for="languagesKnown">Languages Known:</label></td>
                <td>
                    <input type="checkbox" name="languagesKnown[]" value="English"> English<br>
                    <input type="checkbox" name="languagesKnown[]" value="Spanish"> Spanish<br>
                    <input type="checkbox" name="languagesKnown[]" value="French"> French<br>
                </td>
            </tr>
            <tr>
                <td><label for="homeNo">Home No:</label></td>
                <td><input type="tel" name="homeNo" required></td>
            </tr>
            <tr>
                <td><label for="officeNo">Office No:</label></td>
                <td><input type="tel" name="officeNo" required></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" id="btn" value="Submit"></td>
            </tr>
        </table>
    </form>
</body>

</html>