<?php
include '12_con.php';

//echo "Deletion Works";
if (isset($_GET['deleteid'])) {
    $id = $_GET['deleteid'];

    $sql = "delete from crud where id=$id";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        //echo '<script>alert("Deleted Sucessfully")</script>';
        header('location:12_display.php');
    } else {
        echo "Failed deletion";
    }
}
