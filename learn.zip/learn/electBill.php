<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electricity Bill Calculator</title>
</head>

<body>

    <?php
    // Function to calculate electricity bill based on units consumed and given tariff
    function calculateElectricityBill($unitsConsumed, $tariffRate)
    {
        $billAmount = $unitsConsumed * $tariffRate;
        return $billAmount;
    }

    // Check if the form is submitted
    if (isset($_POST['submit'])) {
        // Retrieve user input
        $unitsConsumed = isset($_POST["units"]) ? (float)$_POST["units"] : 0;

        // Check if units consumed is a positive number
        if ($unitsConsumed >= 0) {
            // Assuming a fixed tariff rate for simplicity
            $tariffRate = 3.0; // Change this according to your tariff

            // Calculate the electricity bill
            $billAmount = calculateElectricityBill($unitsConsumed, $tariffRate);

            // Display the result

            echo "<h2>Electricity Bill Details</h2>";
            echo "<p>Units Consumed: $unitsConsumed kWh</p>";
            echo "<p>Tariff Rate: Rs.$tariffRate per kWh</p>";
            echo "<p>Total Bill Amount: Rs.$billAmount</p>";
        } else {
            echo "<p>Please enter a valid number of units consumed.</p>";
        }
    }
    ?>

    <!-- HTML form for user input -->
    <form method="post" action="">
        <label for="units">Enter Units Consumed:</label>
        <input type="number" name="units" id="units" required>
        <br><br>
        <input type="submit" value="Calculate Bill" name="submit">
    </form>

</body>

</html>